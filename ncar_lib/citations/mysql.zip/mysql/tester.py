"""
test the pubs vs peopleDB
"""
from PubsDB import PubsDB
from PeopleDB import PeopleDB
from essl_record_types import AuthorRec

def getDistinctPersonIds ():
	"""
	grab a list of DISTINCT person_id values from the author table
	"""
	person_ids = []
	query = "SELECT DISTINCT person_id FROM author WHERE person_id is not NULL and person_id != 0"
	authorRows = PubsDB()._doSelect (query)
	print "%d unique person_id values found" % len(authorRows)
	person_ids = map (lambda x: x[0], authorRows)
	return person_ids
	
	
distinct_person_ids = getDistinctPersonIds()
print "%d distinct person_ids found" % len (distinct_person_ids)


