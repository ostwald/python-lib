
"""
process data from PUBs database to create Citation records
"""
import os, sys
from Generic_Processor import GenericProcessor
from Author import Author
from citation import Citation
from mysql.PubsDB import PubsDB, PublicationRec, AuthorData
		
class PubsProcessor (GenericProcessor):
	"""
	a processor for PUBS data
	"""
	destDir = "PUBS_metadata"
	id_prefix = "PUBS"
	
	def __init__ (self, startid=None, limit=None, write=1):
		"""
		populate self.records from PubsDB and then call process records
		"""
		GenericProcessor.__init__ (self, startid, limit, write)
		self.db = PubsDB() 
		where = "pubstatus = 'published' AND class = 'refereed'"
		self.records = self.db.getPubs(where=where)
		print "about to process %d records" % min (self.limit, len (self.records))
		self.processRecords()
		
	def makeDataDict (self, rec):
		"""
		make the data structure from which the Citation record will be built
		"""
		data = {}
		data['title'] = rec['title']
		data['year'] = rec['year']
		data['pubname'] = self.db.getPubname (rec['pubname_id'])
		data['editor'] = rec['editor']
		data['volume'] = rec['volume']
		data['pages'] = rec['pages']

		data['pubstatus'] = rec['pubstatus']
		data['statusdate'] = rec['statusdate']

		data['type'] = rec['type']
		data['authors'] = self.makeAuthorList (rec)
		
		## ---- pubs-specific fields
		data['pub_id'] = rec['pub_id']
		data['publisher'] = self.db.getPublisher (rec['publisher_id'])
		data['doi'] = rec['doi']
		data['url'] = rec['url']
		data['meetstartdate'] = rec['meetstartdate'] 
		data['meetenddate'] = rec['meetenddate'] 
		data['class'] = rec['class'] 
		data['meetcity'] = rec['meetcity'] 
		data['meetstateprov'] = rec['meetstateprov'] 
		data['meetcountrycode'] = rec['meetcountrycode'] 
		data['collaboration'] = rec['collaboration'] 
		data['meetdate'] = rec['meetdate'] 
		return data
		
	def makeAuthorList (self, rec):
		"""
		create a list of Author instances for provided record
		"""
		authors = []
		authorRecs = self.db.getAuthorRecs(rec['pub_id'])
		for authorRec in authorRecs:
			try:
				authorData = AuthorData (self.db, authorRec)
			except:
				print "Author Data Error: %s" % sys.exc_info()[1]
				authorData = authorRec
			lastname = authorData.lastname
			firstname = authorData.firstname
			middlename = authorData.middlename
			suffix = hasattr (authorData, 'suffix') and authorData.suffix or None
			order = authorData.authororder
			person_id = authorData.person_id
			upid = authorData.upid
			authors.append (Author (lastname, firstname, middlename, suffix, order, person_id, upid))
		return authors

		
if __name__ == '__main__':
	
	foo = PubsProcessor (startid=None, limit=None)
