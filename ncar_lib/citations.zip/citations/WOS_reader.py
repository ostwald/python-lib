"""
ultimately want to have enough info to produce "AMS/ASR format (as specified by Pubs) ..."
"""

import sys, os, time
from schema import wos2pubs_fields
from UserList import UserList
from UserDict import UserDict
from misc.titlecase import titlecase
from Generic_Processor import Author

class WOSXlsReader (UserList):
	"""
	Reads a tab-delimited file of WOS Citation data and produces an unordered list
	of 'WOSRecord' instances
	"""
	schema = None
	records = []
	
	def __init__ (self, path):
		UserList.__init__ (self)
		lines = open (path, 'r').read().split('\n')
		print "%d lines read" % len (lines)
		self.schema = lines[0].split('\t')
				
		for line in lines[1:]:
			if line:
				self.append (WOSRecord (line, self.schema))
			
	def report (self):
		
		print '\n%d Records' % len(self)
		for rec in self:
			print rec
		
	def showSchema (self):
		for field in self.schema:
			if wos2pubs_fields.has_key (field):
				print "%s -> %s" % (field, wos2pubs_fields[field])
			else:
				print "%s -> NOT FOUND" % field
			
class WOSRecord (UserDict):
	"""
	Record corresponding to one line of a tab-delimited WOSData file
	
	extracts fields corresponding to 'wos2pubs_fields.keys" and discards the rest
	the field names themselves 
	"""
	def __init__ (self, rec_data, schema):
		UserDict.__init__ (self)
		data_fields = rec_data.split('\t')
		for i, wos_header in enumerate (schema):
			# WOS header (e.g., "PT")
			
			if not wos_header in wos2pubs_fields.keys():
				continue
				
			# field is the pubs field  for wos_header (e.g. "Pub Type" for "PT")
			field = wos2pubs_fields[wos_header]
			data = data_fields[i]
			
			# remove surrounding quotes if applicable
			if data and data[0] in ['"', "'"] and data[0] == data[-1]:
				data = data[1:-1]
			self[field] = data
			
	def _getPages (self):
		return "%s-%s" % (self['begin-page'], self['end-page'])
		
	def _getYear (self):
		return self['Pub-Year']
		
		
	def toSmartSentenceCase (self, s):
		"""
		return string with first letter capitalized and any letter following
		a colon capitalized, but all others lower case
		"""
		ret = ""
		doCap = 1
		for i,ch in enumerate(s):
			if doCap and ch != " ":
				ret = ret + ch.upper()
				doCap = 0
			else:
				ret = ret + ch.lower()
				if ch == ':':
					doCap = 1
		return ret
		
	def _getTitle (self):
		# return titlecase(self['Title'].lower())
		return self.toSmartSentenceCase (self['Title'])
		
	def _getAuthors (self):
		authors = []
		data = self['authors']
		if not data: return authors
		for i, name in enumerate(data.split(';')):
			lastname = firstname = middlename = ""
			lastname = name.split (',')[0].strip()
			lastname = titlecase (lastname.lower())
			authororder = i + 1
			try:
				initials = name.split (',')[1]
			except:
				initials = None
			if initials:				
				initials = initials.strip()
				if len(initials) == 2:
					# initials = "%s. %s." % (initials[0], initials[1])
					firstname = initials[0]
					middlename = initials[1]
				if len(initials) == 1:
					# initials = "%s." % initials[0]
					firstname = initials[0]
				# authors.append ('%s, %s' % (lastname, initials))
				authors.append (Author (lastname, firstname, middlename, authororder))
		return authors
		
	def _getPubName (self):
		return titlecase(self['pubname'].lower())
		
	def _getPubStatus (self):
		"""
		all WOS entries are published (this is an 'enum' value in Pubs DB)
		"""
		return "published"
		
	def _getPubType (self):
		"""
		normalize WOS PT field to pubsDB 'type' field
		NOTE: the only values for this field are 'J' and 'C', but all the entries seem to be for
		journals, so for now 'journal' is always returned (this is 'enum' value in PubsDB).
		"""
		# pubtype = self['Pub Type']
		# if pubtype == 'J': return "journal"
		# if pubtype == 'C': return "proceedings"
		# else:
			# raise TypeError, "unknown pub type value: '%s'", pubtype
		return 'journal'
		
	def _getVolume (self):
		"""
		this field holds all part, volume, issue information!
		"""
		ret = ""
		v = self['Volume']
		i = self['Issue']
		p = self['Part Name']

		if v and i:
			ret = "%s(%s)" % (v, i)
		else:
			if v:
				ret = "vol. %s" % v
			if i:
				if ret:
					ret = "%s, i. %s" % (ret, i)
				else:
					ret = "i. %s" % i
		if p:
			if ret:
				ret = "%s, %s" % (ret, p)
			else:
				ret = "%s" % p		
		return ret
		
	def _getPubDate (self):
		"""
		REQUIRE a year, and do the best we can to build a more precise date. 
		
		'Pub-date' is most often something like "27-Feb", but can be simply "Feb" or even blank
		
		we return a value in the same PubsDb format ("2009-10-26")
		"""
		pd = self['Pub-date']
		py = self['Pub-Year']
		if not py:
			raise ValueError, "no pub-year supplied"
			
		splits = pd.split('-')
		day = month = None
		if len(splits) == 2:
			day = splits[0].strip()
			month = splits[1].strip()
		if len(splits) == 1:
			month = splits[0]
		if day:
			try:
				int(day)
			except:
				# print 'bad day: %s' % day
				day = None
		day = day or "1"		 # if day cannot be determined, use 1
		month = month or "Jan"   # if month cannot be determined, use jan
		
		wos_date_format = "%b-%d-%Y"  # OCT-26-2009
		pubs_date_format = "%Y-%m-%d" # 2009-10-26
		
		wos_date_str = "%s-%s-%s" % (titlecase(month.lower()), day, py)
		try:
			dateObj = time.strptime (wos_date_str, wos_date_format)
		except:
			# print ("unable to format wos_date_str: " % wos_date_str)
			dateObj = time.strptime ("Jan-1-%s" % py, wos_date_format)
			
		return time.strftime (pubs_date_format, dateObj)
		
	def report (self):
		# return self['Title'][:80]
		s = [];add=s.append
		add ("title: %s" % self._getTitle())
		add ("year: %s" % self._getYear())
		add ("editor: %s" % self['editor'])
		
		add ("pubname: %s" % self._getPubName())
		
		add ("volume: %s" % self._getVolume()) # self['volume'])
		add ("pages: %s" % self._getPages())
		add ("pubstatus: %s" % self._getPubStatus())
		add ("statusdate: %s" % self._getPubDate())
		add ("type: %s" % self._getPubType())
		
		add ("wos_id: %s" % self['wos_id'])
		add ("authors:")
		for author in self._getAuthors():
			add ("\t" + str(author))
		
		return '\n'.join(s) + '\n'
		
	def brief_report (self):
		s = [];add=s.append
		add ("title: %s" % self._getTitle())
		add ("pubname: %s" % self._getPubName())
		add ("authors:")
		for author in self._getAuthors():
			add ("\t" + str(author))
		return '\n'.join(s) + '\n'
			
	def __repr__ (self):
		# return self._getVolume()
		return self.brief_report()
		
if __name__ == '__main__':
	path = "WOS_data_files/WOS_11501-11816.txt"
	wos = WOSXlsReader(path)
	wos.report()
		
		
