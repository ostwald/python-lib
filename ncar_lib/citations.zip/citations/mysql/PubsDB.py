"""
Connects to essl_publications and extracts records from various Tables
"""
import sys
from AbstractDB import AbstractDB
from essl_record_types import PublicationRec, PubnameRec, PublisherRec, AuthorRec
from EsslPeopleDB import EsslPeopleDB
from PeopleDB import PeopleDB

errors = []

class PubsDB (AbstractDB):
	
	host = "mysql.ucar.edu"
	user = "rduser"
	password = "rd.user"
	db = "essl_publications"
	
	def __init__ (self, host=None, user=None, password=None, db=None):
		
		"""
		establishes connection with PUBs DB and initializes schemas for each of the
		tables that will be accessed
		"""
		AbstractDB.__init__ (self, host, user, password, db)
		
		self.essl_peopleDB = EsslPeopleDB()
		self.peopleDB = PeopleDB()
		
		PublicationRec.schema = self.getSchema ("publication")
		PubnameRec.schema = self.getSchema ("pubname")
		PublisherRec.schema = self.getSchema ("publisher")
		AuthorRec.schema = self.getSchema ("author")
		
	def getPubs (self, start=None, end=None, where=None):
		"""
		returns list of PublicationRecs corresponding to specified
		- rows of the database (start, end), and 
		- where clause, e.g., "pubstatus = 'published' AND class = 'refereed'"
		"""
		rows = self.getRows ("publication", start, end, where)
		return map (PublicationRec, rows)
		
	def getPub (self, pub_id):
		"""
		return PublicationRec for specified pub_id
		"""
		data = self.getRecordFromKey ('pub_id', pub_id, 'publication')
		if data:
			return PublicationRec (data)
		
	def getPublisher (self, publisher_id):
		"""
		return name of publisher for specified publisher_id
		"""
		rec = self.getPublisherRec (publisher_id)
		if rec:
			return rec['publisher']
		
	def getPublisherRec (self, publisher_id):
		"""
		return PublisherRec for specified publisher_id
		"""
		data = self.getRecordFromKey ('publisher_id', publisher_id, 'publisher')
		if data:
			return PublisherRec (data)
		
	def getPubname (self, pubname_id):
		rec = self.getPubnameRec (pubname_id)
		if rec:
			return rec['pubname']
		
	def getPubnameRec (self, pubname_id):
		"""
		should be at most ONE record per pubname_id
		"""
		data = self.getRecordFromKey ('pubname_id', pubname_id, 'pubname')
		if data:
			return PubnameRec (data)
	
	def getAuthorRecs (self, pub_id):
		"""
		returns list of AuthorRecs for the authors associated with
		specified publication (pub_id)
		"""
		queryStr = "SELECT * FROM author WHERE pub_id='%s'" % pub_id
		return map (AuthorRec, self.doSelect (queryStr))
		
def fleshRecord (db, pub):
	"""
	debugging method to show all information associated with a given
	pub record by extracting information from appropriate PUBs DB tables
	"""
	
	import sys
	showpubfield = lambda a: sys.stdout.write ('%s: %s\n' % (a, pub[a]))
	
	print '\n'
	showpubfield("pub_id")
	showpubfield("title")
	showpubfield("year")
	showpubfield("editor")
	
	print 'pubname:', db.getPubname (pub['pubname_id'])
	print 'publisher:', db.getPublisher (pub['publisher_id'])
	
	showpubfield("volume")
	showpubfield("pages")
	showpubfield("doi")
	showpubfield("url")
	showpubfield("pubstatus")
	showpubfield("statusdate")
	showpubfield("meetstartdate")
	showpubfield("meetenddate")
	showpubfield("class")
	showpubfield("type")
	showpubfield("meetcity")
	showpubfield("meetstateprov")
	showpubfield("meetcountrycode")
	showpubfield("collaboration")
	showpubfield("meetdate")
	showAuthors (db, pub)
	
		
def showAuthors (db, pub):
	authorRecs = db.getAuthorRecs(pub['pub_id'])
	for authorRec in authorRecs:
		print AuthorData (db, authorRec)
		
		
class AuthorData:
	
	lastname = firstname = middlename = authororder = person_id = upid = None
		
	def __init__ (self, db, authorRec):
		"""
		Class to hold the best data we can find in association with a particular author
		"""
		self.db = db
		self.authorRec = authorRec
		self.lastname = authorRec.lastname
		self.firstname = authorRec.firstname
		self.middlename = authorRec.middlename
		self.authororder = authorRec.authororder
		self.person_id = authorRec.person_id
		
		if (self.person_id):
			try:
				self._update_from_essl_peopleDB (self.person_id)
			except KeyError:
				errors.append ("%s (%s)" % (self, sys.exc_info()[1]))
		
		
		# self.upid = self._get_upid ()
		# if (self.upid):
			# try:
				# self._update_from_peopleDB (self.upid)
			# except:
				# errors.append ("%s (%s)" % (self, sys.exc_info()[1]))
				
	def _update_from_essl_peopleDB (self, person_id):
		"""
		we assume the info in the essl_person db is best, so we override
		info from the authorRec with that from the essl_person rec having the 
		same person_id
		"""
		personRec = self.db.essl_peopleDB.getPerson (person_id)
		if not personRec:
			raise KeyError, 'Record not found for %s' % person_id
		self.lastname = personRec.lastname
		self.firstname = personRec.firstname
		self.middlename = personRec.middlename
		self.upid = personRec.upid
	
	def _get_upid (self):
		"""
		NOT USED FOR NOW - INSTEAD WE USE THE PERSON_ID AND TAKE THE UPID FROM THERE
		get the upid for this author, ensuring that pubs and peopleDB information is
		consistent
		"""
		essl_upid = self.db.essl_peopleDB.getUpid (self.authorRec.person_id)
	
		# use authorRec to find match in poepleDB - NOTE: would we do better to 
		# use essl_people.person record (which has full names)?? (maybe if candidates != 1)
		candidates = self.db.peopleDB.pubsSearch (name_last=self.lastname, 
											 	  name_first=self.firstname+"%", 
												  name_middle=self.middlename+"%")
		
		if (len(candidates) > 1):
			errors.append ("%s (more than one PeopleDB candidates found using initials for search)" % self)
												  
		# print "\t%d candidates found" % len (candidates)
		people_upid = len(candidates) == 1 and candidates[0]['upid'] or None
		
		# raise an error if people_upid and essl_upid are not consistent
		if people_upid and essl_upid and people_upid != essl_upid:
			errors.append ("%s (upid mismatch: peopleDB=%s, essl=%s)" % (self, people_upid, essl_upid))
			upid = people_upid
			
		return (people_upid or essl_upid) or None
		
	def _update_from_peopleDB (self, upid):
		"""
		NOT CURRENTLY USED ... for now essl_person table is authority
		we assume the info in the peopleDB is best, so we draw author names from peopleDB
		"""
		peopleRec = self.db.peopleDB.getPerson (upid)
		if not peopleRec:
			raise KeyError, "PersonDB entry not found for upid: %s" % upid
		self.lastname = peopleRec['name_last']
		self.firstname = peopleRec['name_first']
		self.middlename = peopleRec['name_middle']
	
	def __repr__ (self):
		"""
		make a string representation of this author showing name, upid, etc
		"""
		
		name = '%s, %s. %s.' % (self.lastname, self.firstname, self.middlename)
		info = 'person_id: %s, order: %d, upid: %s' % (self.authorRec.person_id, \
													   self.authororder, \
													   self.upid)
		notes = ""
		# if candidates: notes = " ... %d PeopleDB matches found" % len(candidates)
		
		return '%s -- %s' % (name, info) 	
	
	
def doCountTester ():		
	db = PubsDB()
	query = "FROM publication WHERE pubstatus = 'published' AND class = 'refereed'"
	n = db.doCount (query)
	print 'there are %d records' % n
	
def batchTester ():
	db = PubsDB()
	pubs = db.getPubs(0,200)
	print 'there are %d pubs' % len(pubs)
	for pub in pubs:
		# fleshRecord (db, pub)
		# print pub['pub_id'], pub['publisher_id']
		
		showAuthors (db, pub)

	
	if errors:
		print "\n ERRORS"
		for i in errors:
			print '- %s' % i

def whereTester ():
	db = PubsDB()
	where = "pubstatus = 'published'"
	pubs = db.getPubs(where=where)
	print 'there are %d pubs' % len(pubs)

		
def recordTester ():
	db = PubsDB() 
	pub_id = '200981' # '103397'
	pub = db.getPub (pub_id)
	if pub:
		fleshRecord (db, pub)
	else:
		print "nothing found for pub_id = '%s'" % pub_id	
		
if __name__ == "__main__":
	batchTester()
	# recordTester()
	# whereTester()
	# doCountTester()


		
