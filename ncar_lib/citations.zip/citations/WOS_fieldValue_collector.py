import sys, os, re
from WOS_Processor import WOSProcessor
from WOS_Batch_Processor import WOS_Batch_Processor


class FieldValueWOSProcessor (WOSProcessor):
	"""
	processes a single WOS file. collects the unique values for specified field from the
	raw data in the spreadsheet, and makes it available in "unique_values"
	"""
	
	id_prefix = "NOT USED"
	unique_values = []
	
	def __init__ (self, path, field, limit=None):
		self.field = field
		WOSProcessor.__init__ (self, path, startid=1, limit=limit, write=0)
	
	def processRecords (self):
		for rec in self.records:
			# data = self.makeDataDict (rec)
			value = rec[self.field]
			if not value in self.unique_values:
				self.unique_values.append (value)
				
			# print "%d - %s" % (self.reccounter+1, rec['pubname'])

			self.reccounter = self.reccounter + 1
			if self.reccounter >= self.limit: break
		
class WOSFieldValueCollector (WOS_Batch_Processor):
	"""
	subclass of pubname collector that maintains a list of unique pubname values
	accross all spreadsheets processed
	"""
	
	unique_values = []
	
	def __init__ (self, field):
		self.field = field
		filenames = os.listdir(self.dataDir)
		filenames.sort()
		for filename in filenames:
			root, ext = os.path.splitext (filename)
			if not (root.startswith ('WOS') and ext == '.txt'):
				print "skipping %s" % filename
			print filename
			path = os.path.join (self.dataDir, filename)
			self.processFile (path)
			
		self.unique_values.sort()
	
	def processFile (self, path):
		pnp = FieldValueWOSProcessor (path, self.field)
		
		for name in pnp.unique_values:
			if not name in self.unique_values:
				self.unique_values.append (name)
				
	def write (self):
		
		sorted_values = self.unique_values
		sorted_values.sort()
		
		filename = "uniqueWOSvalues_" + self.field + ".txt"
		fp = open (filename, 'w')
		fp.write ("\n".join (sorted_values))
		fp.close()
		print "wrote %d sorted unique values for '%s' to %s" % (len (sorted_values), self.field, filename)
		
		
def FieldValueWOSProcessorTester():
	datafile = "WOS_data_files/WOS_11001-11500.txt"
	field = 'pubname'
	pnp = FieldValueWOSProcessor (datafile, field, limit=2)
		
if __name__ == '__main__':
	
	# PubNameWOSProcessorTester()
	collector = WOSFieldValueCollector ('pubname')
	collector.write()
