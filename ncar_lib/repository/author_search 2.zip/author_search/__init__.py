"""
scripts to implement PAR report (see https://wiki.ucar.edu/x/KZlCB)

exposes AuthorReporter, AuthorSearchResult, OsmAuthorReporter, OsmAuthorSearchResult
"""
from author import Author
from authorReporter import AuthorReporter
from authorSearchResult import AuthorSearchResult
from osmPar import AuthorReporter, AuthorSearchResult
