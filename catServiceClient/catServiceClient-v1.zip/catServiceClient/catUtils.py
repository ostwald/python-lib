import re

def stripLearningResourceContent (responseText):
	from JloXml.RegExUtils import getTagPattern
	pat = getTagPattern ("LearningResourceContent")
	m = pat.search (responseText)
	if m:
		return responseText.replace (m.group(1), "")
	return responseText
