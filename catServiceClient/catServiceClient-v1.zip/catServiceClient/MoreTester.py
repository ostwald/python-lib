from UrlUtils import cmpUrls
from urls import *

cmpUrls (ssDoc, mltDoc)
