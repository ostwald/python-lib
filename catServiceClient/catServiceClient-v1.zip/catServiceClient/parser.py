import sys, re, os
# from JloXml import RegExUtils
from JloXml.RegExUtils import getTagPattern
path = "h:/python-lib/CATServiceClient/parseme.xml"

s = open (path).read()
# print s

pat = getTagPattern ("LearningResourceContent")
m = pat.search (s)
if m:
##	print m.group(1)
	print s.replace (m.group(1), "")
else:
	print "NOT FOUND"

