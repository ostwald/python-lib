
urlFoo = "http://cat.nsdl.org:8280/casaa/service.do?username=nest&startGrade=1&endGrade=12&author=National+Science+Education+Standards+%28NSES%29&maxResults=10&topic=Science&query=http%3A%2F%2Fga.water.usgs.gov%2Fedu%2Fearthrivers.html&password=p&method=suggestStandards"

urlDoc1 = "http://cat.nsdl.org:8280/casaa/service.do?method=moreLikeTheseStandards&username=test&password=p&author=California&query=http://ga.water.usgs.gov/edu/earthrivers.html&selectedStandards=http://purl.org/ASN/resources/S101A366,http://purl.org/ASN/resources/S1024EFB&topic=Science&startGrade=9&endGrade=12&maxResults=5"

urlDoc2 = "http://cat.nsdl.org:8280/casaa/service.do?method=moreLikeTheseStandards&username=test&password=p&query=http://ga.water.usgs.gov/edu/runoff.html&selectedStandards=http://purl.org/ASN/resources/S1006B00,http://purl.org/ASN/resources/S103AB8D&topic=Science&startGrade=9&endGrade=12&maxResults=2"

urlMail1 = "http://cat.nsdl.org:8280/casaa/service.do?method=suggestStandards&username=test&password=p&query=http://ga.water.usgs.gov/edu/earthrivers.html&topic=Science&startGrade=9&endGrade=12&maxResults=2"

urlMail2 = "http://cat.nsdl.org:8280/casaa/service.do?method=moreLikeTheseStandards&username=test&password=p&author=California&query=http://ga.water.usgs.gov/edu/earthrivers.html&selectedStandards=http://purl.org/ASN/resources/S101A366,http://purl.org/ASN/resources/S1024EFB&topic=Science&startGrade=9&endGrade=12&maxResults=5"

urlTry1 = "http://cat.nsdl.org:8280/casaa/service.do?method=suggestStandards&username=test&password=p&endGrade=12&query=http%3A%2F%2Fga.water.usgs.gov%2Fedu%2Fearthrivers.html&topic=Science&startGrade=1&maxResults=10&author=National+Science+Education+Standards+%28NSES%29"

urlTry2 = "http://cat.nsdl.org:8280/casaa/service.do?method=moreLikeTheseStandards&username=test&password=p&selectedStandards=http%3A%2F%2Fpurl.org%2FASN%2Fresources%2FS100ABE0%2Chttp%3A%2F%2Fpurl.org%2FASN%2Fresources%2FS101369E&endGrade=12&query=http%3A%2F%2Fga.water.usgs.gov%2Fedu%2Fearthrivers.html&topic=Science&startGrade=1&maxResults=10&author=National+Science+Education+Standards+%28NSES%29"

ssDoc = "http://cat.nsdl.org:8280/casaa/service.do?method=suggestStandards&username=test&password=p&query=http://ga.water.usgs.gov/edu/earthrivers.html&topic=Science&startGrade=9&endGrade=12&maxResults=2"

mltDoc = "http://cat.nsdl.org:8280/casaa/service.do?method=moreLikeTheseStandards&username=test&password=p&query=http://ga.water.usgs.gov/edu/earthrivers.html&selectedStandards=http://purl.org/ASN/resources/S101A366,http://purl.org/ASN/resources/S1024EFB&topic=Science&startGrade=9&endGrade=12&maxResults=2"

## (Decoded) Urls that work in succession when submitted via browser
ss = "http://cat.nsdl.org:8280/casaa/service.do?method=suggestStandards&username=test&password=p&endGrade=12&query=http://ga.water.usgs.gov/edu/earthrivers.html&topic=Science&startGrade=9&maxResults=2&author=National Science Education Standards (NSES)"
mlt = "http://cat.nsdl.org:8280/casaa/service.do?method=moreLikeTheseStandards&username=test&password=p&selectedStandards=http://purl.org/ASN/resources/S10084E8,http://purl.org/ASN/resources/S1011306&endGrade=12&query=http://ga.water.usgs.gov/edu/earthrivers.html&topic=Science&startGrade=9&maxResults=2&author=National Science Education Standards (NSES)"

## (ENcoded) Urls that work in succession when submitted via browser
ssEn = "http://cat.nsdl.org:8280/casaa/service.do?method=suggestStandards&username=test&password=p&endGrade=12&query=http%3A%2F%2Fga.water.usgs.gov%2Fedu%2Fearthrivers.html&topic=Science&startGrade=9&maxResults=2&author=National+Science+Education+Standards+%28NSES%29"
mltEn = "http://cat.nsdl.org:8280/casaa/service.do?method=moreLikeTheseStandards&username=test&password=p&selectedStandards=http%3A%2F%2Fpurl.org%2FASN%2Fresources%2FS10084E8,http%3A%2F%2Fpurl.org%2FASN%2Fresources%2FS1011306&endGrade=12&query=http%3A%2F%2Fga.water.usgs.gov%2Fedu%2Fearthrivers.html&topic=Science&startGrade=9&maxResults=2&author=National+Science+Education+Standards+%28NSES%29"

## latest version
latest = "http://cat.nsdl.org:8280/casaa/service.do?method=suggestStandards&username=test&password=p&query=http://ga.water.usgs.gov/edu/earthrivers.html&topic=Science&startGrade=9&endGrade=12&maxResults=2&selectedStandards=http://purl.org/ASN/resources/S103F170,http://purl.org/ASN/resources/S1029FE1"
