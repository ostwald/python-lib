#!/usr/bin/env python

import sys, os, string
from serviceclient import ServiceClient, URL, createInstance
createUrlInstance = createInstance
del createInstance

import urls
import CATGlobals
from suggestStandardsResponseDoc import SuggestStandardsResponse, Standard
from catUtils import stripLearningResourceContent
from catClient import CatClient

## contrain both author and topic or response takes FOREVER
baseParams = {
	"username": "test",
	"password": "p",
	"method": "suggestStandards",
	"query": "http://ga.water.usgs.gov/edu/earthrivers.html",
	"startGrade": "1",
	"endGrade": "12",
	"maxResults": "2",
	"topic": "Science",
	"author": "National Science Education Standards (NSES)"
	}

coloradoParams = {
	"query": "http://www.geo-world.org/volcano/tectonics.html",
	"startGrade": "-1",
	"endGrade": "-1",
	"maxResults": "10",
	"topic": "Science",
	"author": "Colorado"
	}
	
ngesParams = {
	"query": "http://www.geo-world.org/volcano/tectonics.html",
	"startGrade": "-1",
	"endGrade": "-1",
	"maxResults": "10",
	"topic": "Geography",
	## "author": "National Geography Education Standards (NGES)"
	## "author": "National Geography Education Standards"
	"author": "National Council on Economic Education (NCEE) - Science"
	## "author": "NGES"
	}	
	
# params to test the pre-k grade level
preKParams = {
	"query": "http://volcano.oregonstate.edu/",
	"startGrade": "-1",
	"endGrade": "-1",
	"maxResults": "10",
	"topic": "Math",
	"author": "Florida"
	}
	
## additional params for the "more like these" command
## usage: 
more_like_these_params = {
	"method": "moreLikeTheseStandards",
	"suggestedStandards": [
	    "http://purl.org/ASN/resources/S100ABE0",
        "http://purl.org/ASN/resources/S101369E"]
	}.update (baseParams)

class SuggesterClient (CatClient):
	
	results = None
	
	def getResponse (self):
		response = ServiceClient.getResponse (self, preprocessor=stripLearningResourceContent)
		if not response.hasError():
			# self.results = self.getResults(response.doc)
			self.results = SuggestStandardsResponse (xml=response.doc.recordXml)
		return response
			
	def getIds(self):
		"""
		returns a list of standards obtained from result doc
		"""
		ids = []
		if not self.results:
			return []
		for std in self.results.standards:
			ids.append (std.Identifier)
		return ids
		
	def report (self):
		print "\nRESULTS (%d)" % len (self.getIds())
		for id in self.getIds():
			print "\t", id
		#for std in self.results.standards:
			# print '--------------------------\n%s' % std
		print self.results
			

def getSuggestions (params):

	baseUrl = CATGlobals.baseUrl
	client = SuggesterClient (baseUrl)
	request = client.setRequest (params)
	print request.report()
	response = client.getResponse()
	if response.hasError():
		print response.error

	else:
		# print response.doc
		client.report()	
	
if __name__ == "__main__":
	params = baseParams

	customParams = {
		"query": "http://www.geo-world.org/volcano/tectonics.html",
		# "query": "http://www.sedl.org/scimath/pasopartners/pdfs/dinosaurs.pdf",
		"startGrade": "-1",
		"endGrade": "-1",
		"maxResults": "10",
#		"topic": "Science",
#		"topic": "Geography",
		"topic": "ALL",
# 		"author": "Colorado"
#		"author": "National Geography Education Standards (NGES)"
# 		"author": "National Geography Education Standards"
#		"author": "NGES"
#		'author': "American Association of Advancement of Science Project 2061"
		'author': "National Geography Education Standards (NGES)"
	}
	
	params.update (customParams)
	getSuggestions (params)
	
					   

		

	
