# baseUrl = "http://cat.nsdl.org:8280/casaa/service.do"

common_params = {
	"username": "test",
	"password": "p",
	"endGrade": "12",
	"query": "http://ga.water.usgs.gov/edu/earthrivers.html",
	"topic": "Science",
	"startGrade": "1",
	"maxResults": "10",
	"author": "National Science Education Standards (NSES)"
	}

suggest_standards_params = {
	"method": "suggestStandards",
	}
suggest_standards_params.update (common_params)

more_like_these_params = {
	"method": "moreLikeTheseStandards",
	"suggestedStandards": [
	    "http://purl.org/ASN/resources/S100ABE0",
        "http://purl.org/ASN/resources/S101369E"]
	}
more_like_these_params.update (common_params)

servers = {
	'cornell' : { 
		'baseUrl' : "http://cat.nsdl.org:8280/casaa/service.do",
		'username': 'test',
		'password': 'p'
	},
	
	'cnlp' : { 
		'baseUrl' : "http://grace.syr.edu:8080/casaa/service.do",
		'username': 'nsdl',
		'password': 'digi!lib'
	}
}
