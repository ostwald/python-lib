#!/usr/bin/env python

import sys, os, site
import string
# import serviceclient
# from serviceClient import ServiceClient
from serviceclient import ServiceRequest, ServiceResponse, ServiceError, ServiceClient, URL
from urls import *
from CATGlobals import baseUrl, suggest_standards_params, more_like_these_params
from suggestStandardsResponseDoc import SuggestStandardsResponse, Standard

"""
we want to parse the response from the Client to show different things, like
suggested standard ids
"""

class CatClient (ServiceClient):
	
	result = None
	
	def getResponse (self):
		response = ServiceClient.getResponse (self)
		if not response.hasError():
			self.result = response.doc
			# self.results = self.getResults(response.doc)
			# self.results = SuggestStandardsResponse (xml=response.doc.recordXml)
		return response
		
	def report (self):
		print "\nCAT CLIENT RESULT"
		print self.result

def tester (url):
	baseUrl = url.getBaseUrl()
	## print "baseUrl", baseUrl
	params = url.getParams()
	url.printParams()
	client = CatClient (baseUrl)
	request = client.setRequest (params)
	# print request.report()
	response = client.getResponse()
	if response.hasError():
		print response.error

	else:
		# print response.doc
		client.report()	
	
	
if __name__ == "__main__":
	# url = URL (ssDoc)
	url = URL (latest)
	url.addParam ("author", "Colorado")
	url.replaceParam ("maxResults", "10")
	
	print "CASE 1"
	tester (url)

	
					   

		

	
