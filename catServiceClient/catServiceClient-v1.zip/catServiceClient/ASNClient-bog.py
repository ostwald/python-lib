#!/usr/bin/env python

import sys, os, site
import string
from serviceclient.ServiceClient import *
from serviceclient.URL import URL
from urls import *
from CATGlobals import baseUrl, suggest_standards_params, more_like_these_params
from suggestStandardsResponseDoc import SuggestStandardsResponse, Standard

"""
we want to parse the response from the Client to show different things, like
suggested standard ids
"""

class ASNClient (ServiceClient):
	
	results = None
	
	def getResponse (self):
		response = ServiceClient.getResponse (self)
		if not response.hasError():
			# self.results = self.getResults(response.doc)
			self.results = SuggestStandardsResponse (xml=response.doc.recordXml)
		return response
			
	def getIds(self):
		"""
		returns a list of standards obtained from result doc
		"""
		ids = []
		if not self.results:
			return []
		for std in self.results.standards:
			ids.append (std.Identifier)
		return ids
		
	def report (self):
		print "\nRESULTS"
		for id in self.getIds():
			print "\t", id

# http://localhost:10080/asn/service.do?verb=GetStandard&id=http%3A%2F%2Fpurl.org%2FASN%2Fresources%2FS103ECD5

def tester (url):
	## print "baseUrl", baseUrl
	params = url.getParams()
	url.printParams()
	client = ASNClient (baseUrl)
	request = client.setRequest (params)
	tester (url)
 
	
					   

		

	
